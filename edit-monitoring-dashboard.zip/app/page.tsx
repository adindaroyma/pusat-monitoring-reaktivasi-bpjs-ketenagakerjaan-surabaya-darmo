export default function Page() {
  return (
    <main className="min-h-screen">
      <iframe
        src="/dashboard.html"
        title="Pusat Monitoring Klaim dan Reaktivasi BPJS"
        className="h-screen w-full border-0"
      />
    </main>
  )
}
